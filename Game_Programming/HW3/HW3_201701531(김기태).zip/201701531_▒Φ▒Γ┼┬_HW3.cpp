#include "201701531_�����_HW3.h"

// �������� ����
//ĳ���� ��ǥ ����
D2D1_POINT_2F mycharacter_point = { 800, 400 };
D2D1_SIZE_U mycharacter_size;
int score = 0;
int move = 0;
bool moveright = true;
bool isshow = false;

//������ �ֹ� �Ϸᶧ���� �ҷ����� �ʱ�
bool islock = false;
//�ֹ�����
int makepizza = 0;
int orderpizza = 0;

bool orderfinish = false;

//�������� ũ�� ����
int windows_width = 1500;
int windows_height = 900;

//ĳ���� ��Ʈ�� �ӽ�����
ID2D1BitmapBrush* character_tmp;


//������� ���� üũ
int pizza_ingredient[7] = { 0 };

double top_box_x_point[] = {
	120,
	240,
	360,
	480,
	600,
	720,
	840,
	960,
	1080
};

double bottom_box_x_point[] ={
	100,
	200,
	300,
	400,
	500,
	600,
	700,
	800,
	900,
	1100};


// ���� ���α׷��� ������ �Լ�
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE /*hPrevInstance*/, LPSTR /*lpCmdLine*/, int /*nCmdShow*/)
{
	if (SUCCEEDED(CoInitialize(NULL)))
	{
		{
			DemoApp app;
			if (SUCCEEDED(app.Initialize(hInstance)))
			{
				app.RunMessageLoop();
			}
		}
		CoUninitialize();
	}
	return 0;
}

// ������. ��� �������� �ʱ�ȭ��.
DemoApp::DemoApp() :
	m_hwnd(NULL),
	m_pDirect2dFactory(NULL),
	m_pRenderTarget(NULL),
	m_pLightSlateGrayBrush(NULL),
	m_pCornflowerBlueBrush(NULL),

	//�׵θ�
	m_border_brush(NULL),

	//�귯��
	m_box_brush01(NULL),
	m_box_brush02(NULL),
	m_box_brush03(NULL),
	m_box_brush04(NULL),
	m_box_brush05(NULL),
	m_box_brush06(NULL),
	m_box_brush07(NULL),
	m_box_brush08(NULL),
	m_box_brush09(NULL),
	m_box_brush10(NULL),
	m_white(NULL),

	//�����ڽ�
	m_pTransparentBox(NULL),

	//�ؽ�Ʈ
	m_pTextBrush_white(NULL),
	m_pTextBrush_black(NULL),
	m_pDWriteFactory(NULL),
	m_pTextFormat(NULL),
	m_pTextFormat_bigsize(NULL),

	//���
	m_pWICFactory(NULL),
	m_pBitmap(NULL),
	m_pBitmap_desk(NULL),
	m_ptables1(NULL),
	m_ptables2(NULL),

	//ĳ����
	m_pMyCharacter(NULL),
	m_pOtherCharacter1(NULL),
	m_pOtherCharacter2(NULL),
	m_pOtherCharacter3(NULL),
	m_pOtherCharacter4(NULL),
	m_pOtherCharacter5(NULL),

	//��ǳ��
	m_pspeech_bubble(NULL),

	//���� ����
	m_pizza_dow(NULL),
	m_pizza_cheese(NULL),
	m_pizza_mushroom(NULL),
	m_pizza_onion(NULL),
	m_pizza_olive(NULL),
	m_pizza_pepperoni(NULL),
	m_pizza_pmang(NULL),

	//Geometry
	top_PathGeometry(NULL),
	bottom_PathGeometry(NULL),
	guest_PathGeometry(NULL),
	guest_PathGeometry_back(NULL),
	child_PathGeometry(NULL),

	//Brush
	m_pOtherCharacter1_brush(NULL),
	m_pOtherCharacter2_brush(NULL),
	m_pOtherCharacter3_brush(NULL),
	m_pOtherCharacter4_brush(NULL),
	m_pOtherCharacter5_brush(NULL)

{
}

// �Ҹ���. ���� ���α׷��� �ڿ��� �ݳ���.
DemoApp::~DemoApp()
{
	//���� �Լ����� �����
	DiscardDeviceResources();
	SAFE_RELEASE(m_pDirect2dFactory);

	//�ؽ�Ʈ
	SAFE_RELEASE(m_pTextBrush_white);
	SAFE_RELEASE(m_pTextBrush_black);
	SAFE_RELEASE(m_pDWriteFactory);
	SAFE_RELEASE(m_pTextFormat);
	SAFE_RELEASE(m_pTextFormat_bigsize);

	//���
	SAFE_RELEASE(m_pWICFactory);
	SAFE_RELEASE(m_pBitmap);
	SAFE_RELEASE(m_pBitmap_desk);
	SAFE_RELEASE(m_ptables1);
	SAFE_RELEASE(m_ptables2);

	//ĳ����
	SAFE_RELEASE(m_pMyCharacter);
	SAFE_RELEASE(m_pOtherCharacter1);
	SAFE_RELEASE(m_pOtherCharacter2);
	SAFE_RELEASE(m_pOtherCharacter3);
	SAFE_RELEASE(m_pOtherCharacter4);
	SAFE_RELEASE(m_pOtherCharacter5);

	//��ǳ��
	SAFE_RELEASE(m_pspeech_bubble);
	
	//���� ����
	SAFE_RELEASE(m_pizza_dow);
	SAFE_RELEASE(m_pizza_cheese);
	SAFE_RELEASE(m_pizza_mushroom);
	SAFE_RELEASE(m_pizza_onion);
	SAFE_RELEASE(m_pizza_olive);
	SAFE_RELEASE(m_pizza_pepperoni);
	SAFE_RELEASE(m_pizza_pmang);

	//Geometry
	SAFE_RELEASE(top_PathGeometry);
	SAFE_RELEASE(bottom_PathGeometry);
	SAFE_RELEASE(guest_PathGeometry);
	SAFE_RELEASE(guest_PathGeometry_back)
	SAFE_RELEASE(child_PathGeometry);
}

// ���� ���α׷��� �����츦 ������. ��ġ ������ �ڿ��� ������.
HRESULT DemoApp::Initialize(HINSTANCE hInstance)
{
	HRESULT hr;

	// ��ġ ������ �ڿ��� ������.
	hr = CreateDeviceIndependentResources();

	if (SUCCEEDED(hr))
	{
		// ������ Ŭ������ �����..
		WNDCLASSEX wcex = { sizeof(WNDCLASSEX) };
		wcex.style = CS_HREDRAW | CS_VREDRAW;
		wcex.lpfnWndProc = DemoApp::WndProc;
		wcex.cbClsExtra = 0;
		wcex.cbWndExtra = sizeof(LONG_PTR);
		wcex.hInstance = hInstance;
		wcex.hbrBackground = NULL;
		wcex.lpszMenuName = NULL;
		wcex.hCursor = LoadCursor(NULL, IDI_APPLICATION);
		wcex.lpszClassName = L"D2DDemoApp";
		RegisterClassEx(&wcex);

		// �����츦 ������. (Title��)
		m_hwnd = CreateWindow(
			L"D2DDemoApp", L"201701531_�����_HW3",
			WS_OVERLAPPEDWINDOW, CW_USEDEFAULT, CW_USEDEFAULT,
			windows_width, windows_height, NULL, NULL, hInstance, this
		);
		hr = m_hwnd ? S_OK : E_FAIL;
		if (SUCCEEDED(hr))
		{
			ShowWindow(m_hwnd, SW_SHOWNORMAL);
			UpdateWindow(m_hwnd);
		}
		QueryPerformanceFrequency(&m_nFrequency);
		QueryPerformanceCounter(&m_nPrevTime);
	}

	//�մ� ���� ��� ����
	if (SUCCEEDED(hr))
	{
		float length = 0;
		hr = guest_PathGeometry->ComputeLength(NULL, &length);

		if (SUCCEEDED(hr))
		{
			m_Animation.SetStart(0); //start at beginning of path
			m_Animation.SetEnd(length); //length at end of path
			m_Animation.SetDuration(5.0f); //seconds

			ShowWindow(m_hwnd, SW_SHOWNORMAL);
			UpdateWindow(m_hwnd);
		}
	}

	//�մ�_������ ���� ��� ����
	if (SUCCEEDED(hr))
	{
		float length = 0;
		hr = guest_PathGeometry_back->ComputeLength(NULL, &length);

		if (SUCCEEDED(hr))
		{
			m_Animation.SetStart(0); //start at beginning of path
			m_Animation.SetEnd(length); //length at end of path
			m_Animation.SetDuration(5.0f); //seconds

			ShowWindow(m_hwnd, SW_SHOWNORMAL);
			UpdateWindow(m_hwnd);
		}
	}
	return hr;
}

// ��ġ ������ �ڿ����� ������. �̵� �ڿ��� ������ ���� ���α׷��� ����Ǳ� ������ ��ȿ��.
HRESULT DemoApp::CreateDeviceIndependentResources()
{
	static const WCHAR msc_fontName[] = L"Verdana";
	static const FLOAT msc_fontSize = 50;

	HRESULT hr = S_OK;
	ID2D1GeometrySink* pSink = NULL;

	//HW3
	// WIC ���丮�� ������.
	hr = CoCreateInstance(CLSID_WICImagingFactory, NULL, CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&m_pWICFactory));
	// D2D ���丮�� ������.
	if (SUCCEEDED(hr)) {
		hr = D2D1CreateFactory(D2D1_FACTORY_TYPE_SINGLE_THREADED, &m_pDirect2dFactory);
	}

	if (SUCCEEDED(hr))
	{
		// Create a shared DirectWrite factory
		hr = DWriteCreateFactory(
			DWRITE_FACTORY_TYPE_SHARED,
			__uuidof(IDWriteFactory),
			reinterpret_cast<IUnknown**>(&m_pDWriteFactory)
		);
	}

	if (SUCCEEDED(hr))
	{
		// Create a DirectWrite text format object.
		hr = m_pDWriteFactory->CreateTextFormat(
			L"Verdana",     // The font family name.
			NULL,           // The font collection (NULL sets it to use the system font collection).
			DWRITE_FONT_WEIGHT_REGULAR,
			DWRITE_FONT_STYLE_NORMAL,
			DWRITE_FONT_STRETCH_NORMAL,
			13.0f,
			L"ko-kr",
			&m_pTextFormat
		);

		hr = m_pDWriteFactory->CreateTextFormat(
			L"Verdana",     // The font family name.
			NULL,           // The font collection (NULL sets it to use the system font collection).
			DWRITE_FONT_WEIGHT_REGULAR,
			DWRITE_FONT_STYLE_NORMAL,
			DWRITE_FONT_STRETCH_NORMAL,
			21.0f,
			L"ko-kr",
			&m_pTextFormat_bigsize
		);
	}

	//���� ��� ���� �׸���
	if (SUCCEEDED(hr))
	{
		hr = m_pDirect2dFactory->CreatePathGeometry(&child_PathGeometry);

		if (SUCCEEDED(hr))
		{
			hr = child_PathGeometry->Open(&pSink);

			if (SUCCEEDED(hr))
			{
				D2D1_POINT_2F currentLocation = { 200.0f, 650.0f };

				pSink->BeginFigure(currentLocation, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddBezier(D2D1::BezierSegment(D2D1::Point2F(400, 700), D2D1::Point2F(600, 600), D2D1::Point2F(900, 650)));
				//pSink->AddBezier(D2D1::BezierSegment(D2D1::Point2F(300, 650), D2D1::Point2F(750, 700), D2D1::Point2F(900, 650)));
				//pSink->AddLine(D2D1::Point2F(800, 650));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				hr = pSink->Close();
			}
			SAFE_RELEASE(pSink);
		}
	}

	//����� ���� ���� �׸���
	if (SUCCEEDED(hr))
	{
		hr = m_pDirect2dFactory->CreatePathGeometry(&top_PathGeometry);

		if (SUCCEEDED(hr))
		{
			hr = top_PathGeometry->Open(&pSink);

			if (SUCCEEDED(hr))
			{
				//���� ���
				D2D1_POINT_2F currentLocation = { 240.0f, 10.0f };
				pSink->BeginFigure(currentLocation, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(1080, 10));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				//���� �ߴ�
				D2D1_POINT_2F currentLocation2 = { 240.0f, 110.0f };
				pSink->BeginFigure(currentLocation2, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(1080, 110));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				//���� �ϴ�
				D2D1_POINT_2F currentLocation3 = { 240.0f, 150.0f };
				pSink->BeginFigure(currentLocation3, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(1080, 150));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				//���� ��(Left)
				D2D1_POINT_2F side1 = { top_box_x_point[1], 10.0f };
				pSink->BeginFigure(side1, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(top_box_x_point[1], 150));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				//���� ��(Right)
				D2D1_POINT_2F side2 = { top_box_x_point[8], 10.0f };
				pSink->BeginFigure(side2, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(top_box_x_point[8], 150));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				//���� ��(����)
				D2D1_POINT_2F inside1 = { top_box_x_point[2], 10.0f };
				pSink->BeginFigure(inside1, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(top_box_x_point[2], 150));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				D2D1_POINT_2F inside2 = { top_box_x_point[3], 10.0f };
				pSink->BeginFigure(inside2, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(top_box_x_point[3], 150));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				D2D1_POINT_2F inside3 = { top_box_x_point[4], 10.0f };
				pSink->BeginFigure(inside3, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(top_box_x_point[4], 150));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				D2D1_POINT_2F inside4 = { top_box_x_point[5], 10.0f };
				pSink->BeginFigure(inside4, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(top_box_x_point[5], 150));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				D2D1_POINT_2F inside5 = { top_box_x_point[6], 10.0f };
				pSink->BeginFigure(inside5, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(top_box_x_point[6], 150));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				D2D1_POINT_2F inside6 = { top_box_x_point[7], 10.0f };
				pSink->BeginFigure(inside6, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(top_box_x_point[7], 150));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				hr = pSink->Close();
			}
			SAFE_RELEASE(pSink);
		}
	}

	//�ϴ��� ���� ���� �׸���
	if (SUCCEEDED(hr))
	{
		hr = m_pDirect2dFactory->CreatePathGeometry(&bottom_PathGeometry);

		if (SUCCEEDED(hr))
		{
			hr = bottom_PathGeometry->Open(&pSink);

			if (SUCCEEDED(hr))
			{
				//���� ���
				D2D1_POINT_2F currentLocation1 = { 200.0f, 350.0f };
				pSink->BeginFigure(currentLocation1, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(1100, 350));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				//���� �ߴ�
				D2D1_POINT_2F currentLocation2 = { 200.0f, 400.0f };
				pSink->BeginFigure(currentLocation2, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(1100, 400));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				//���� �ϴ�
				D2D1_POINT_2F currentLocation3 = { 200.0f, 600.0f };
				pSink->BeginFigure(currentLocation3, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(1100, 600));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				//���� ��(Left)
				D2D1_POINT_2F side1 = { bottom_box_x_point[1], 350.0f };
				pSink->BeginFigure(side1, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(bottom_box_x_point[1], 600));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				//���� ��(Right)
				D2D1_POINT_2F side2 = { bottom_box_x_point[9], 350.0f };
				pSink->BeginFigure(side2, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F( bottom_box_x_point[9], 600));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				//���� ��(����)
				D2D1_POINT_2F inside1 = { bottom_box_x_point[2], 350.0f };
				pSink->BeginFigure(inside1, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(bottom_box_x_point[2], 600));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				D2D1_POINT_2F inside2 = { bottom_box_x_point[3], 350.0f };
				pSink->BeginFigure(inside2, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F( bottom_box_x_point[3], 600));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				D2D1_POINT_2F inside3 = { bottom_box_x_point[4], 350.0f };
				pSink->BeginFigure(inside3, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F( bottom_box_x_point[4], 600));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				D2D1_POINT_2F inside4 = { bottom_box_x_point[5], 350.0f };
				pSink->BeginFigure(inside4, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(bottom_box_x_point[5], 600));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				D2D1_POINT_2F inside5 = { bottom_box_x_point[6], 350.0f };
				pSink->BeginFigure(inside5, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(bottom_box_x_point[6], 600));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				D2D1_POINT_2F inside6 = { bottom_box_x_point[7], 350.0f };
				pSink->BeginFigure(inside6, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(bottom_box_x_point[7], 600));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				D2D1_POINT_2F inside7 = { bottom_box_x_point[8], 350.0f };
				pSink->BeginFigure(inside7, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddLine(D2D1::Point2F(bottom_box_x_point[8], 600));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);

				hr = pSink->Close();
			}
			SAFE_RELEASE(pSink);
		}
	}

	//�մ��� ��� ���� �׸���
	if (SUCCEEDED(hr))
	{
		hr = m_pDirect2dFactory->CreatePathGeometry(&guest_PathGeometry);

		if (SUCCEEDED(hr))
		{
			hr = guest_PathGeometry->Open(&pSink);

			if (SUCCEEDED(hr))
			{
				D2D1_POINT_2F currentLocation = { 1450.0f, 850.0f };
				pSink->BeginFigure(currentLocation, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddBezier(D2D1::BezierSegment(D2D1::Point2F(1450, 850), D2D1::Point2F(1150, 750), D2D1::Point2F(1000, 600)));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);
				hr = pSink->Close();
			}
			SAFE_RELEASE(pSink);
		}
	}

	//�մ�_�������� ��� ���� �׸���
	if (SUCCEEDED(hr))
	{
		hr = m_pDirect2dFactory->CreatePathGeometry(&guest_PathGeometry_back);

		if (SUCCEEDED(hr))
		{
			hr = guest_PathGeometry_back->Open(&pSink);

			if (SUCCEEDED(hr))
			{
				D2D1_POINT_2F currentLocation = { 1000.0f, 600.0f };
				pSink->BeginFigure(currentLocation, D2D1_FIGURE_BEGIN_HOLLOW);
				pSink->AddBezier(D2D1::BezierSegment(D2D1::Point2F(1000, 600), D2D1::Point2F(1150, 750), D2D1::Point2F(1450, 850)));
				pSink->EndFigure(D2D1_FIGURE_END_OPEN);
				hr = pSink->Close();
			}
			SAFE_RELEASE(pSink);
		}
	}
	return hr;
}


// ��ġ ������ �ڿ����� ������. ��ġ�� �ҽǵǴ� ��쿡�� �̵� �ڿ��� �ٽ� �����ؾ� ��.
HRESULT DemoApp::CreateDeviceResources()
{
	HRESULT hr = S_OK;
	// Create a Direct2D factory.

	if (!m_pRenderTarget)
	{
		RECT rc;
		GetClientRect(m_hwnd, &rc);
		D2D1_SIZE_U size = D2D1::SizeU(rc.right - rc.left, rc.bottom - rc.top);

		// D2D ����Ÿ���� ������.
		hr = m_pDirect2dFactory->CreateHwndRenderTarget(D2D1::RenderTargetProperties(), D2D1::HwndRenderTargetProperties(m_hwnd, size), &m_pRenderTarget);

		//�̹����ε�
		if (SUCCEEDED(hr))
		{
			//���
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\pizza_shop.jpg", 1500, 900, &m_pBitmap);
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\pizza_shop_desk.png", 1500, 900, &m_pBitmap_desk);
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\tables1.png", 1500, 900, &m_ptables1);
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\tables2.png", 1500, 900, &m_ptables2);

			//ĳ����
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\char3.png", 500, 800, &m_pMyCharacter);
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\char1.png", 500, 800, &m_pOtherCharacter1);
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\char2.png", 500, 800, &m_pOtherCharacter2);
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\char4.png", 500, 800, &m_pOtherCharacter3);
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\char5.png", 500, 800, &m_pOtherCharacter4);
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\char6.png", 500, 800, &m_pOtherCharacter5);


			//��ǳ��
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\speech_bubble.png", 800, 600, &m_pspeech_bubble);

			//���� ����
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\pizza\\����.png", 800, 600, &m_pizza_dow);
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\pizza\\ġ��.png", 800, 600, &m_pizza_cheese);
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\pizza\\����.png", 800, 600, &m_pizza_mushroom);
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\pizza\\����.png", 800, 600, &m_pizza_onion);
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\pizza\\�ø���.png", 800, 600, &m_pizza_olive);
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\pizza\\���۷δ�.png", 800, 600, &m_pizza_pepperoni);
			hr = LoadBitmapFromFile(m_pRenderTarget, m_pWICFactory, L".\\img\\pizza\\�Ǹ�.png", 800, 600, &m_pizza_pmang);

		}

		if (SUCCEEDED(hr))
		{
			// ȸ�� ���� ������. //���ڸ� �׸��� �뵵
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::LightGray), &m_pLightSlateGrayBrush);
		}
		if (SUCCEEDED(hr))
		{
			// �������� ���� ��ġ ��(����)
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::CornflowerBlue), &m_pCornflowerBlueBrush);
		}
		if (SUCCEEDED(hr))
		{
			// ����� ���� �� �巡�� �� �� �����̴� ���ڸ� ���� ��
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::Gray), &m_pTransparentBox);
		}
		if (SUCCEEDED(hr))
		{
			// �׵θ�
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::Black), &m_border_brush);
		}
		//�귯�� ����
		if (SUCCEEDED(hr))
		{
			// �ڽ� �� ����
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::Red), &m_box_brush01);
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::Orange), &m_box_brush02);
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::Yellow), &m_box_brush03);
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::Green), &m_box_brush04);
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::LightBlue), &m_box_brush05);
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::CadetBlue), &m_box_brush06);
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::MediumPurple), &m_box_brush07);
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::LightPink), &m_box_brush08);
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::Olive), &m_box_brush09);
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::Aqua), &m_box_brush10);
			hr = m_pRenderTarget->CreateSolidColorBrush(D2D1::ColorF(D2D1::ColorF::White), &m_white);
		}
		if (SUCCEEDED(hr))
		{
			//�۾�
			// Create a solid color brush for writing text.
			hr = m_pRenderTarget->CreateSolidColorBrush(
				D2D1::ColorF(D2D1::ColorF::White),
				&m_pTextBrush_white
			);

			hr = m_pRenderTarget->CreateSolidColorBrush(
				D2D1::ColorF(D2D1::ColorF::Black),
				&m_pTextBrush_black
			);
		}

		//��Ʈ�� �귯�� ����
		if (SUCCEEDED(hr)) {
			D2D1_BITMAP_BRUSH_PROPERTIES propertiesXClampYClamp = D2D1::BitmapBrushProperties(
				D2D1_EXTEND_MODE_CLAMP,
				D2D1_EXTEND_MODE_CLAMP,
				D2D1_BITMAP_INTERPOLATION_MODE_NEAREST_NEIGHBOR
			);
			if (SUCCEEDED(hr))
			{
				hr = m_pRenderTarget->CreateBitmapBrush(
					m_pOtherCharacter1,
					propertiesXClampYClamp,
					&m_pOtherCharacter1_brush
				);

			}
			if (SUCCEEDED(hr))
			{
				hr = m_pRenderTarget->CreateBitmapBrush(
					m_pOtherCharacter2,
					propertiesXClampYClamp,
					&m_pOtherCharacter2_brush
				);

			}
			if (SUCCEEDED(hr))
			{
				hr = m_pRenderTarget->CreateBitmapBrush(
					m_pOtherCharacter3,
					propertiesXClampYClamp,
					&m_pOtherCharacter3_brush
				);

			}
			if (SUCCEEDED(hr))
			{
				hr = m_pRenderTarget->CreateBitmapBrush(
					m_pOtherCharacter4,
					propertiesXClampYClamp,
					&m_pOtherCharacter4_brush
				);

			}
			if (SUCCEEDED(hr))
			{
				hr = m_pRenderTarget->CreateBitmapBrush(
					m_pOtherCharacter5,
					propertiesXClampYClamp,
					&m_pOtherCharacter5_brush
				);

			}
		}
	}
	return hr;
}

// ��ġ ������ �ڿ����� �ݳ���. ��ġ�� �ҽǵǸ� �̵� �ڿ��� �ٽ� �����ؾ� ��.
void DemoApp::DiscardDeviceResources()
{
	SAFE_RELEASE(m_pRenderTarget);
	SAFE_RELEASE(m_pLightSlateGrayBrush);
	SAFE_RELEASE(m_pCornflowerBlueBrush);
	//�׵θ�
	SAFE_RELEASE(m_border_brush);

	//�귯��
	SAFE_RELEASE(m_box_brush01);
	SAFE_RELEASE(m_box_brush02);
	SAFE_RELEASE(m_box_brush03);
	SAFE_RELEASE(m_box_brush04);
	SAFE_RELEASE(m_box_brush05);
	SAFE_RELEASE(m_box_brush06);
	SAFE_RELEASE(m_box_brush07);
	SAFE_RELEASE(m_box_brush08);
	SAFE_RELEASE(m_box_brush09);
	SAFE_RELEASE(m_box_brush10);
	SAFE_RELEASE(m_white);

	//�����ڽ�
	SAFE_RELEASE(m_pTransparentBox);

	//��Ʈ�ʺ귯��
	SAFE_RELEASE(m_pOtherCharacter1_brush);
	SAFE_RELEASE(m_pOtherCharacter2_brush);
	SAFE_RELEASE(m_pOtherCharacter3_brush);
	SAFE_RELEASE(m_pOtherCharacter4_brush);
	SAFE_RELEASE(m_pOtherCharacter5_brush);
}

// ���� ������ �޽��� ������ ������.
void DemoApp::RunMessageLoop()
{
	MSG msg;

	while (GetMessage(&msg, NULL, 0, 0))
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
}

//string -> wstring���� ��ȯ�� ���� �Լ�
std::wstring strconv(const std::string& _src)
{
	USES_CONVERSION;
	return std::wstring(A2W(_src.c_str()));

};

static float float_time_draw_guest = 0.0f;
static float total_time_draw_guest = 0.0f;
//�մԱ׸���
void DemoApp::draw_guest(HRESULT hr, D2D1_SIZE_F rtSize)
{
	//�ִϸ��̼�
	float length = m_Animation.GetValue(float_time_draw_guest);

	//�ð��� ���� �Ÿ����
	D2D1_POINT_2F point, spoint;
	D2D1_POINT_2F tangent;

	hr = guest_PathGeometry->ComputePointAtLength(
		length,
		NULL,
		&point,
		&tangent);

	//�մ��� ��� ���� �׸���
	D2D1::Matrix3x2F tmp = D2D1::Matrix3x2F::Translation(
		point.x - 100,
		point.y - 200
	);

	D2D1_RECT_F rcBrushRect = D2D1::RectF(0, 0, rtSize.width, rtSize.height);

	//������
	D2D1_MATRIX_3X2_F scale = D2D1::Matrix3x2F::Scale(D2D1::Size(0.32f, 0.32f), D2D1::Point2F(0, 0));

	//�մ��� ��� ���� ���� �׸��� (�׸� ���� ��)
	m_pRenderTarget->SetTransform(scale * tmp);
	m_pRenderTarget->FillRectangle(&rcBrushRect, character_tmp);
	if (float_time_draw_guest >= m_Animation.GetDuration())
	{
		float_time_draw_guest = 0.0f;
	}
	else
	{
		if (float_time_draw_guest < 4.4) {
			LARGE_INTEGER CurrentTime;
			QueryPerformanceCounter(&CurrentTime);
			float_time_draw_guest += 0.05;
		}
		else {
			//��ǳ��
			m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
			m_pRenderTarget->DrawBitmap(
				m_pspeech_bubble,
				D2D1::RectF(
					1050,
					250,
					1050 + 300,
					250 + 250),
				0.8,
				D2D1_BITMAP_INTERPOLATION_MODE_LINEAR
			);

			WCHAR mouse_text[100];
			swprintf_s(mouse_text, L"���� �ּ���.\n[�䱸���� : %d��]\n[�ϼ� : %d�� / %d��]", orderpizza, makepizza, orderpizza);

			m_pRenderTarget->DrawText(
				mouse_text,
				wcslen(mouse_text),
				m_pTextFormat_bigsize,
				D2D1::RectF(1110.0f, 310.0f, 1370.0f, 500.0f),
				m_pTextBrush_black
			);
		}
	}
}

//�մ�_������ �׸���
void DemoApp::draw_guest_back(HRESULT hr, D2D1_SIZE_F rtSize)
{
	//�ִϸ��̼�
	static float float_time = 0.0f;
	static float total_time = 0.0f;
	float length = m_Animation.GetValue(float_time);

	//�ð��� ���� �Ÿ����
	D2D1_POINT_2F point, spoint;
	D2D1_POINT_2F tangent;

	hr = guest_PathGeometry_back->ComputePointAtLength(
		length,
		NULL,
		&point,
		&tangent);

	//�մ��� ��� ���� �׸���
	D2D1::Matrix3x2F tmp = D2D1::Matrix3x2F::Translation(
		point.x - 100,
		point.y - 200
	);

	D2D1_RECT_F rcBrushRect = D2D1::RectF(0, 0, rtSize.width, rtSize.height);

	//������
	D2D1_MATRIX_3X2_F scale = D2D1::Matrix3x2F::Scale(D2D1::Size(0.32f, 0.32f), D2D1::Point2F(0, 0));

	//�մ��� ��� ���� ���� �׸��� (�׸� ���� ��)
	m_pRenderTarget->SetTransform(scale * tmp);
	m_pRenderTarget->FillRectangle(&rcBrushRect, character_tmp);
	if (float_time >= m_Animation.GetDuration())
	{
		float_time = 0.0f;
	}
	else
	{
		if (float_time < 1.0) {
			//��ǳ��
			m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
			m_pRenderTarget->DrawBitmap(
				m_pspeech_bubble,
				D2D1::RectF(
					1050,
					250,
					1050 + 300,
					250 + 250),
				0.8,
				D2D1_BITMAP_INTERPOLATION_MODE_LINEAR
			);

			WCHAR mouse_text[100];
			swprintf_s(mouse_text, L"�����մϴ�.");
			//swprintf_s(mouse_text, L"���� �ּ���.\n[�䱸���� : %d��]\n[�ϼ� : %d�� / %d��]", orderpizza, makepizza, orderpizza);

			m_pRenderTarget->DrawText(
				mouse_text,
				wcslen(mouse_text),
				m_pTextFormat_bigsize,
				D2D1::RectF(1110.0f, 340.0f, 1370.0f, 500.0f),
				m_pTextBrush_black
			);
			float_time += 0.05;
		}
		else if (float_time >= 1.0 && float_time < 4.8) {
			LARGE_INTEGER CurrentTime;
			QueryPerformanceCounter(&CurrentTime);
			float_time += 0.05;
		}
		else {
			islock = false;
			makepizza = 0;
			float_time = 0.0f;
			total_time = 0.0f;
			float_time_draw_guest = 0.0f;
			total_time_draw_guest = 0.0f;
		}
	}
}


void DemoApp::draw_pizza(HRESULT hr, D2D1_SIZE_F rtSize)
{
	m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
	m_pRenderTarget->DrawBitmap(
		m_pizza_dow,
		D2D1::RectF(
			250,
			10,
			250 + 100,
			10 + 100)
	);
	m_pRenderTarget->DrawBitmap(
		m_pizza_cheese,
		D2D1::RectF(
			370,
			10,
			370 + 100,
			10 + 100)
	);
	m_pRenderTarget->DrawBitmap(
		m_pizza_mushroom,
		D2D1::RectF(
			490,
			10,
			490 + 100,
			10 + 100)
	);
	m_pRenderTarget->DrawBitmap(
		m_pizza_onion,
		D2D1::RectF(
			610,
			10,
			610 + 100,
			10 + 100)
	);
	m_pRenderTarget->DrawBitmap(
		m_pizza_olive,
		D2D1::RectF(
			730,
			10,
			730 + 100,
			10 + 100)
	);
	m_pRenderTarget->DrawBitmap(
		m_pizza_pepperoni,
		D2D1::RectF(
			850,
			10,
			850 + 100,
			10 + 100)
	);
	m_pRenderTarget->DrawBitmap(
		m_pizza_pmang,
		D2D1::RectF(
			970,
			10,
			970 + 100,
			10 + 100)
	);
}

void DemoApp::draw_pizza_state(HRESULT hr, D2D1_SIZE_F rtSize)
{
	m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
	D2D1_RECT_F rectangle_tmp;
	for (int i = 1; i < 8; i++) {
		if (pizza_ingredient[i - 1] == 0) {
			m_box_brush04->SetOpacity(0);
		}
		else if (pizza_ingredient[i - 1] == 1) {
			m_box_brush04->SetOpacity(0.333);
		}
		else if (pizza_ingredient[i - 1] == 2) {
			m_box_brush04->SetOpacity(0.666);
		}
		else {
			m_box_brush04->SetOpacity(1);
		}
		rectangle_tmp = D2D1::RectF(top_box_x_point[i], 110, top_box_x_point[i+1], 150);
		m_pRenderTarget->FillRectangle(rectangle_tmp, m_box_brush04);


		WCHAR point_text[100];
		swprintf_s(point_text, L"%d/3", pizza_ingredient[i-1]);
		m_pRenderTarget->DrawText(
			point_text,
			wcslen(point_text),
			m_pTextFormat,
			D2D1::RectF(top_box_x_point[i] + 40, 110 + 10, top_box_x_point[i + 1] + 40, 150 + 10),
			m_pTextBrush_white
		);
	}
}

wchar_t pizza_name[][100] = {
	L"����",
	L"ġ��",
	L"����",
	L"����",
	L"�ø���",
	L"���۷δ�",
	L"�Ǹ�"
};

void DemoApp::draw_pizza_name(HRESULT hr, D2D1_SIZE_F rtSize)
{
	m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
	
	m_white->SetOpacity(0.5);

	D2D1_RECT_F rectangle_tmp;
	for (int i = 1; i < 8; i++) {
		rectangle_tmp = D2D1::RectF(bottom_box_x_point[i], 350, bottom_box_x_point[i + 1], 400);
		m_pRenderTarget->FillRectangle(rectangle_tmp, m_white);

		WCHAR point_text[100];
		if (i == 6) {
			swprintf_s(point_text, L"%s", pizza_name[i - 1]);
			m_pRenderTarget->DrawText(
				point_text,
				wcslen(point_text),
				m_pTextFormat_bigsize,
				D2D1::RectF(bottom_box_x_point[i] + 10, 350 + 10, bottom_box_x_point[i + 1], 400 + 10),
				m_pTextBrush_black
			);
		}
		else {
			swprintf_s(point_text, L"%s", pizza_name[i - 1]);
			m_pRenderTarget->DrawText(
				point_text,
				wcslen(point_text),
				m_pTextFormat_bigsize,
				D2D1::RectF(bottom_box_x_point[i] + 20, 350 + 10, bottom_box_x_point[i + 1] + 20, 400 + 10),
				m_pTextBrush_black
			);
		}
	}
	rectangle_tmp = D2D1::RectF(900, 350, 1100, 400);
	m_pRenderTarget->FillRectangle(rectangle_tmp, m_white);
	WCHAR point_text[100];
	swprintf_s(point_text, L"�ϼ��ϱ�");
	m_pRenderTarget->DrawText(
		point_text,
		wcslen(point_text),
		m_pTextFormat_bigsize,
		D2D1::RectF(920 + 40, 350 + 10, 1100 + 40, 400 + 10),
		m_pTextBrush_black
	);
}


void DemoApp::order_pizza()
{
	if (!islock) {
		//���� 1~4�� ���� �ֹ�
		orderpizza = rand() % 4 + 1;

		//ĳ���� ��ȣ ���� ����
		int character_rand = rand() % 5 + 1;
		if (character_rand == 1) {
			character_tmp = m_pOtherCharacter1_brush;
		}
		else if (character_rand == 2) {
			character_tmp = m_pOtherCharacter2_brush;
		}
		else if (character_rand == 3) {
			character_tmp = m_pOtherCharacter3_brush;
		}
		else if (character_rand == 4) {
			character_tmp = m_pOtherCharacter4_brush;
		}
		else {
			character_tmp = m_pOtherCharacter5_brush;
		}
		islock = true;
	}
}

// Ŭ���̾�Ʈ ������ ȭ���� �׸�.
// ����: �� �Լ��� ����Ǵ� ���ȿ� ��ġ�� �ҽǵǸ� ��ġ ������ �ڿ����� �ݳ���. �� ���� ȣ�� �ÿ� �� �ڿ����� �ٽ� ������.
HRESULT DemoApp::OnRender()
{
	HRESULT hr = S_OK;

	hr = CreateDeviceResources();

	if (SUCCEEDED(hr))
	{
		D2D1_SIZE_F rtSize = m_pRenderTarget->GetSize();

		//BeginDraw -> �׸��� -> EndDraw
		m_pRenderTarget->BeginDraw();
		m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
		m_pRenderTarget->Clear(D2D1::ColorF(D2D1::ColorF::White));

		//HW3 ���׸���
		D2D1_SIZE_F size = m_pBitmap->GetSize();
		D2D1_POINT_2F upperLeftCorner = D2D1::Point2F(0.f, 0.f);
		m_pRenderTarget->DrawBitmap(
			m_pBitmap,
			D2D1::RectF(
				upperLeftCorner.x,
				upperLeftCorner.y,
				upperLeftCorner.x + size.width,
				upperLeftCorner.y + size.height)
		);
		m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());


		//ĳ���ͱ׸���
		D2D1::Matrix3x2F mycharacter_matrix;
		mycharacter_size = m_pMyCharacter->GetPixelSize();
		m_pRenderTarget->DrawBitmap(
			m_pMyCharacter,
			D2D1::RectF(
				mycharacter_point.x,
				mycharacter_point.y,
				mycharacter_point.x + 150,
				mycharacter_point.y + 250)
		);
		m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());

		//å���� �ٽ� �׸���
		m_pRenderTarget->DrawBitmap(
			m_pBitmap_desk,
			D2D1::RectF(
				upperLeftCorner.x,
				upperLeftCorner.y,
				upperLeftCorner.x + size.width,
				upperLeftCorner.y + size.height)
		);

		//������ ����ǥ��
		m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
		WCHAR point_text[100];
		swprintf_s(point_text, L"���� ���� ���� : %d��\n�� �Ǹž� : %d��", score, score * 15000);
		m_pRenderTarget->DrawText(
			point_text,
			wcslen(point_text),
			m_pTextFormat_bigsize,
			D2D1::RectF(1200.0f, 30.0f, 1450.0f, 200.0f),
			m_pTextBrush_white
		);

		////ĳ����1
		//m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
		//m_pRenderTarget->DrawBitmap(
		//	m_pOtherCharacter1,
		//	D2D1::RectF(
		//		800,
		//		500,
		//		800 + 150,
		//		500 + 250)
		//);

		//ĳ����2
		m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
		m_pRenderTarget->DrawBitmap(
			m_pOtherCharacter2,
			D2D1::RectF(
				300 + move,
				500,
				300 + 150 + move,
				500 + 250)
		);
		if (moveright) {
			move += 5;
			if (move >= 550) {
				moveright = false;
			}
		}
		else {
			move -= 5;
			if (move <= -150) {
				moveright = true;
			}
		}

		////ĳ����2
		//m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
		//m_pRenderTarget->DrawBitmap(
		//	m_pOtherCharacter2,
		//	D2D1::RectF(
		//		300,
		//		500,
		//		300 + 150,
		//		500 + 250),
		//	opactiyscore,
		//	D2D1_BITMAP_INTERPOLATION_MODE_LINEAR
		//);
		// 
		// 
		
		//���� ���� ���� ����
		order_pizza();
		//�ִϸ��̼�
		if (makepizza < orderpizza) {
			draw_guest(hr, rtSize);
		}
		m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
		//�ִϸ��̼�
		if (makepizza >= orderpizza) {
			draw_guest_back(hr, rtSize);
		}
		m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());

		//�������
		draw_pizza(hr, rtSize);

		//����������
		draw_pizza_state(hr, rtSize);

		//��������̸�
		draw_pizza_name(hr, rtSize);

		//���̺�1
		m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
		m_pRenderTarget->DrawBitmap(
			m_ptables1,
			D2D1::RectF(
				upperLeftCorner.x,
				upperLeftCorner.y,
				upperLeftCorner.x + size.width,
				upperLeftCorner.y + size.height)
		);

		//���̺�2
		m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
		m_pRenderTarget->DrawBitmap(
			m_ptables2,
			D2D1::RectF(
				upperLeftCorner.x,
				upperLeftCorner.y,
				upperLeftCorner.x + size.width,
				upperLeftCorner.y + size.height)
		);

		m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());

		//��ܱ��� �׸���
		m_pRenderTarget->DrawGeometry(top_PathGeometry, m_box_brush06, 4);
		//�մ԰�α��� �׸���
		m_pRenderTarget->DrawGeometry(guest_PathGeometry, m_box_brush07, 4);
		//���̰�α��� �׸���
		m_pRenderTarget->DrawGeometry(child_PathGeometry, m_box_brush02, 3);

		m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
		m_box_brush01->SetOpacity(0.5);
		//�ϴܱ��� �׸���
		m_pRenderTarget->DrawGeometry(bottom_PathGeometry, m_box_brush01, 4);

		////�»�� ĳ���� ��ġ ǥ���ϱ�
		m_pRenderTarget->SetTransform(D2D1::Matrix3x2F::Identity());
		WCHAR mouse_text[100];
		swprintf_s(mouse_text, L"ĳ���� X��ǥ : %.2f \nĳ���� Y��ǥ : %.2f"
			, mycharacter_point.x, mycharacter_point.y);

		m_pRenderTarget->DrawText(
			mouse_text,
			wcslen(mouse_text),
			m_pTextFormat,
			D2D1::RectF(10.0f, 10.0f, 200.0f, 200.0f),
			m_pTextBrush_white
		); //�»�ܿ� �������� ���� ����

		//�׸����� ǥ����
		hr = m_pRenderTarget->EndDraw();
	}
	if (hr == D2DERR_RECREATE_TARGET)
	{
		hr = S_OK;
		DiscardDeviceResources();
	}
	return hr;
}

// ���� ���α׷����� WM_SIZE �޽����� �߻��Ǹ� �� �Լ��� ����Ÿ���� ũ�⸦ �ٽ� ������.
void DemoApp::OnResize(UINT width, UINT height)
{
	if (m_pRenderTarget)
	{
		// ����: �Ʒ��� �Լ��� ���� �ÿ� ������ ���� ������, ���⿡�� ���� ������ üũ���� �ʰ� �Ѿ�� ��. ������ EndDraw �Լ��� ȣ��� ���� ������ Ȯ�ε� ���̹Ƿ� �׶� ó���ϸ� ��.
		m_pRenderTarget->Resize(D2D1::SizeU(width, height));
	}
}

// ������ �޽����� ó��.
LRESULT CALLBACK DemoApp::WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	LRESULT result = 0;

	if (message == WM_CREATE)
	{
		LPCREATESTRUCT pcs = (LPCREATESTRUCT)lParam;
		DemoApp* pDemoApp = (DemoApp*)pcs->lpCreateParams;

		SetWindowLongPtrW(hwnd, GWLP_USERDATA, PtrToUlong(pDemoApp));

		result = 1;
	}
	else
	{
		DemoApp* pDemoApp = reinterpret_cast<DemoApp*>(static_cast<LONG_PTR>(GetWindowLongPtrW(hwnd, GWLP_USERDATA)));

		bool wasHandled = false;

		//Ű����
		if (GetAsyncKeyState(VK_LEFT) & 0x8000)
		{
			if (mycharacter_point.x >= 200) {
				mycharacter_point.x -= 5;
				mycharacter_point.y += 0.1;
			}
			InvalidateRect(hwnd, NULL, false);
		}
		if (GetAsyncKeyState(VK_RIGHT) & 0x8000)
		{
			if (mycharacter_point.x <= 1000) {
				mycharacter_point.x += 5;
				mycharacter_point.y -= 0.1;
			}
			InvalidateRect(hwnd, NULL, false);
		}
		if (GetAsyncKeyState(VK_UP) & 0x8000)
		{
		}
		if (GetAsyncKeyState(VK_DOWN) & 0x8000)
		{
		}
		if (GetAsyncKeyState(VK_SPACE) & 0x8000)
		{
		}

		if (pDemoApp)
		{
			switch (message)
			{
			case WM_SIZE:
			{
				UINT width = LOWORD(lParam);
				UINT height = HIWORD(lParam);
				pDemoApp->OnResize(width, height);
			}
			result = 0;
			wasHandled = true;
			break;

			case WM_DISPLAYCHANGE:
			{
				InvalidateRect(hwnd, NULL, FALSE);
			}
			result = 0;
			wasHandled = true;
			break;

			case WM_PAINT:
			{
				pDemoApp->OnRender();
				// ���⿡�� ValidateRect�� ȣ������ ���ƾ� OnRender �Լ��� ��� �ݺ� ȣ���.
				//ValidateRect(hwnd, NULL);
			}
			result = 0;
			wasHandled = true;
			break;

			////���콺 ������ ��
			//case WM_MOUSEMOVE:
			//{
			//	return 0;
			//}
			////���콺 ���� ��ư�� �ö� �� (�� �巡�� �ϴٰ� ����)
			//case WM_LBUTTONUP: // ���� �巡�װ� �������� 
			//{
			//	break;
			//}
			////���� ���콺 Ŭ�� ��
			//case WM_LBUTTONDOWN:
			//{
			//	break;
			//}
			//Ű ���� ��
			case WM_KEYDOWN:
			{
				WCHAR input_str;
				input_str = (TCHAR)wParam;
				switch (input_str)
				{
					case VK_SPACE:
					{
						//����
						if (mycharacter_point.x >= bottom_box_x_point[0] + 45 && mycharacter_point.x < bottom_box_x_point[1] + 45) {
							if (pizza_ingredient[0] < 3) {
								pizza_ingredient[0]++;
							}
						}
						//ġ��
						else if (mycharacter_point.x >= bottom_box_x_point[1] + 45 && mycharacter_point.x < bottom_box_x_point[2] + 45) {
							if (pizza_ingredient[1] < 3) {
								pizza_ingredient[1]++;
							}
						}
						//����
						else if (mycharacter_point.x >= bottom_box_x_point[2] + 45 && mycharacter_point.x < bottom_box_x_point[3] + 45) {
							if (pizza_ingredient[2] < 3) {
								pizza_ingredient[2]++;
							}
						}
						//����
						else if (mycharacter_point.x >= bottom_box_x_point[3] + 45 && mycharacter_point.x < bottom_box_x_point[4] + 45) {
							if (pizza_ingredient[3] < 3) {
								pizza_ingredient[3]++;
							}
						}
						//�ø���
						else if (mycharacter_point.x >= bottom_box_x_point[4] + 45 && mycharacter_point.x < bottom_box_x_point[5] + 45) {
							if (pizza_ingredient[4] < 3) {
								pizza_ingredient[4]++;
							}
						}
						//����δ�
						else if (mycharacter_point.x >= bottom_box_x_point[5] + 45 && mycharacter_point.x < bottom_box_x_point[6] + 45) {
							if (pizza_ingredient[5] < 3) {
								pizza_ingredient[5]++;
							}
						}
						//�Ǹ�
						else if (mycharacter_point.x >= bottom_box_x_point[6] + 45 && mycharacter_point.x < bottom_box_x_point[7] + 45) {
							if (pizza_ingredient[6] < 3) {
								pizza_ingredient[6]++;
							}
						}
						//�մ�����
						else if (mycharacter_point.x >= bottom_box_x_point[7] + 45 && mycharacter_point.x < 1045) {
							boolean makefin = true;
							for (int i = 0; i < 7; i++) {
								if (pizza_ingredient[i] != 3) {
									makefin = false;
									break;
								}
							}
							if (makefin) {
								score++;
								makepizza++;
								for (int i = 0; i < 7; i++) {
									pizza_ingredient[i] = 0;
								}
							}
							else {

							}
						}
						else {

						}					
					}
					default:
					{}
				}
				break;
			}
			case WM_DESTROY:
			{
				PostQuitMessage(0);
			}
			result = 1;
			wasHandled = true;
			break;
			}
		}
		if (!wasHandled)
		{
			result = DefWindowProc(hwnd, message, wParam, lParam);
		}
	}
	return result;
}

// Creates a Direct2D bitmap from a resource in the application resource file.
HRESULT DemoApp::LoadBitmapFromResource(ID2D1RenderTarget* pRenderTarget, IWICImagingFactory* pIWICFactory, PCWSTR resourceName, PCWSTR resourceType, UINT destinationWidth, UINT destinationHeight, ID2D1Bitmap** ppBitmap)
{
	HRESULT hr = S_OK;
	IWICBitmapDecoder* pDecoder = NULL;
	IWICBitmapFrameDecode* pSource = NULL;
	IWICStream* pStream = NULL;
	IWICFormatConverter* pConverter = NULL;
	IWICBitmapScaler* pScaler = NULL;

	HRSRC imageResHandle = NULL;
	HGLOBAL imageResDataHandle = NULL;
	void* pImageFile = NULL;
	DWORD imageFileSize = 0;

	// Locate the resource.
	imageResHandle = FindResourceW(HINST_THISCOMPONENT, resourceName, resourceType);

	hr = imageResHandle ? S_OK : E_FAIL;
	if (SUCCEEDED(hr))
	{
		// Load the resource.
		imageResDataHandle = LoadResource(HINST_THISCOMPONENT, imageResHandle);

		hr = imageResDataHandle ? S_OK : E_FAIL;
	}

	if (SUCCEEDED(hr))
	{
		// Lock it to get a system memory pointer.
		pImageFile = LockResource(imageResDataHandle);

		hr = pImageFile ? S_OK : E_FAIL;
	}

	if (SUCCEEDED(hr))
	{
		// Calculate the size.
		imageFileSize = SizeofResource(HINST_THISCOMPONENT, imageResHandle);

		hr = imageFileSize ? S_OK : E_FAIL;
	}

	if (SUCCEEDED(hr))
	{
		// Create a WIC stream to map onto the memory.
		hr = pIWICFactory->CreateStream(&pStream);
	}

	if (SUCCEEDED(hr))
	{
		// Initialize the stream with the memory pointer and size.
		hr = pStream->InitializeFromMemory(
			reinterpret_cast<BYTE*>(pImageFile),
			imageFileSize
		);
	}

	if (SUCCEEDED(hr))
	{
		// Create a decoder for the stream.
		hr = pIWICFactory->CreateDecoderFromStream(
			pStream,
			NULL,
			WICDecodeMetadataCacheOnLoad,
			&pDecoder
		);
	}

	if (SUCCEEDED(hr))
	{
		// Create the initial frame.
		hr = pDecoder->GetFrame(0, &pSource);
	}

	if (SUCCEEDED(hr))
	{
		// Convert the image format to 32bppPBGRA
		// (DXGI_FORMAT_B8G8R8A8_UNORM + D2D1_ALPHA_MODE_PREMULTIPLIED).
		hr = pIWICFactory->CreateFormatConverter(&pConverter);
	}

	if (SUCCEEDED(hr))
	{
		// If a new width or height was specified, create an
		// IWICBitmapScaler and use it to resize the image.
		if (destinationWidth != 0 || destinationHeight != 0)
		{
			UINT originalWidth, originalHeight;
			hr = pSource->GetSize(&originalWidth, &originalHeight);
			if (SUCCEEDED(hr))
			{
				if (destinationWidth == 0)
				{
					FLOAT scalar = static_cast<FLOAT>(destinationHeight) / static_cast<FLOAT>(originalHeight);
					destinationWidth = static_cast<UINT>(scalar * static_cast<FLOAT>(originalWidth));
				}
				else if (destinationHeight == 0)
				{
					FLOAT scalar = static_cast<FLOAT>(destinationWidth) / static_cast<FLOAT>(originalWidth);
					destinationHeight = static_cast<UINT>(scalar * static_cast<FLOAT>(originalHeight));
				}

				hr = pIWICFactory->CreateBitmapScaler(&pScaler);
				if (SUCCEEDED(hr))
				{
					hr = pScaler->Initialize(
						pSource,
						destinationWidth,
						destinationHeight,
						WICBitmapInterpolationModeCubic
					);
				}

				if (SUCCEEDED(hr))
				{
					hr = pConverter->Initialize(
						pScaler,
						GUID_WICPixelFormat32bppPBGRA,
						WICBitmapDitherTypeNone,
						NULL,
						0.f,
						WICBitmapPaletteTypeMedianCut
					);
				}
			}
		}
		else
		{
			hr = pConverter->Initialize(
				pSource,
				GUID_WICPixelFormat32bppPBGRA,
				WICBitmapDitherTypeNone,
				NULL,
				0.f,
				WICBitmapPaletteTypeMedianCut
			);
		}
	}

	if (SUCCEEDED(hr))
	{
		//create a Direct2D bitmap from the WIC bitmap.
		hr = pRenderTarget->CreateBitmapFromWicBitmap(
			pConverter,
			NULL,
			ppBitmap
		);
	}

	SAFE_RELEASE(pDecoder);
	SAFE_RELEASE(pSource);
	SAFE_RELEASE(pStream);
	SAFE_RELEASE(pConverter);
	SAFE_RELEASE(pScaler);

	return hr;
}

// Creates a Direct2D bitmap from the specified file name.
HRESULT DemoApp::LoadBitmapFromFile(ID2D1RenderTarget* pRenderTarget, IWICImagingFactory* pIWICFactory, PCWSTR uri, UINT destinationWidth, UINT destinationHeight, ID2D1Bitmap** ppBitmap)
{
	HRESULT hr = S_OK;

	IWICBitmapDecoder* pDecoder = NULL;
	IWICBitmapFrameDecode* pSource = NULL;
	IWICStream* pStream = NULL;
	IWICFormatConverter* pConverter = NULL;
	IWICBitmapScaler* pScaler = NULL;

	hr = pIWICFactory->CreateDecoderFromFilename(
		uri,
		NULL,
		GENERIC_READ,
		WICDecodeMetadataCacheOnLoad,
		&pDecoder
	);

	if (SUCCEEDED(hr))
	{
		// Create the initial frame.
		hr = pDecoder->GetFrame(0, &pSource);
	}

	if (SUCCEEDED(hr))
	{
		// Convert the image format to 32bppPBGRA
		// (DXGI_FORMAT_B8G8R8A8_UNORM + D2D1_ALPHA_MODE_PREMULTIPLIED).
		hr = pIWICFactory->CreateFormatConverter(&pConverter);
	}

	if (SUCCEEDED(hr))
	{
		// If a new width or height was specified, create an
		// IWICBitmapScaler and use it to resize the image.
		if (destinationWidth != 0 || destinationHeight != 0)
		{
			UINT originalWidth, originalHeight;
			hr = pSource->GetSize(&originalWidth, &originalHeight);
			if (SUCCEEDED(hr))
			{
				if (destinationWidth == 0)
				{
					FLOAT scalar = static_cast<FLOAT>(destinationHeight) / static_cast<FLOAT>(originalHeight);
					destinationWidth = static_cast<UINT>(scalar * static_cast<FLOAT>(originalWidth));
				}
				else if (destinationHeight == 0)
				{
					FLOAT scalar = static_cast<FLOAT>(destinationWidth) / static_cast<FLOAT>(originalWidth);
					destinationHeight = static_cast<UINT>(scalar * static_cast<FLOAT>(originalHeight));
				}

				hr = pIWICFactory->CreateBitmapScaler(&pScaler);
				if (SUCCEEDED(hr))
				{
					hr = pScaler->Initialize(
						pSource,
						destinationWidth,
						destinationHeight,
						WICBitmapInterpolationModeCubic
					);
				}

				if (SUCCEEDED(hr))
				{
					hr = pConverter->Initialize(
						pScaler,
						GUID_WICPixelFormat32bppPBGRA,
						WICBitmapDitherTypeNone,
						NULL,
						0.f,
						WICBitmapPaletteTypeMedianCut
					);
				}
			}
		}
		else // Don't scale the image.
		{
			hr = pConverter->Initialize(
				pSource,
				GUID_WICPixelFormat32bppPBGRA,
				WICBitmapDitherTypeNone,
				NULL,
				0.f,
				WICBitmapPaletteTypeMedianCut
			);
		}
	}
	if (SUCCEEDED(hr))
	{
		// Create a Direct2D bitmap from the WIC bitmap.
		hr = pRenderTarget->CreateBitmapFromWicBitmap(
			pConverter,
			NULL,
			ppBitmap
		);
	}

	SAFE_RELEASE(pDecoder);
	SAFE_RELEASE(pSource);
	SAFE_RELEASE(pStream);
	SAFE_RELEASE(pConverter);
	SAFE_RELEASE(pScaler);

	return hr;
}