#pragma once

// Windows Header Files:
#include <windows.h>
// C RunTime Header Files:
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <wchar.h>
#include <iostream>
#include <string>
#include <atlconv.h>
#include <algorithm>
#include <math.h>
// DX Header Files:
#include <d2d1.h>
#include <d2d1helper.h>
#include <dwrite.h>
#include <wincodec.h>
#include <stdio.h>
#include <tchar.h>
#include <time.h>
#include <Dwmapi.h>

#include "Animation.h"

// �ڿ� ���� ��ȯ ��ũ��.
#define SAFE_RELEASE(p) { if(p) { (p)->Release(); (p)=NULL; } }

// ���� ����� �����ּ� ���.
#ifndef HINST_THISCOMPONENT
EXTERN_C IMAGE_DOS_HEADER __ImageBase;
#define HINST_THISCOMPONENT ((HINSTANCE)&__ImageBase)
#endif

class DemoApp
{
public:
	DemoApp();
	~DemoApp();
	HRESULT Initialize(HINSTANCE hInstance);  // Register the window class and call methods for instantiating drawing resources
	void RunMessageLoop();  // Process and dispatch messages

private:
	HRESULT CreateDeviceIndependentResources();  // Initialize device-independent resources.
	HRESULT CreateDeviceResources();  // Initialize device-dependent resources.
	void DiscardDeviceResources();  // Release device-dependent resource.
	HRESULT OnRender();   // Draw content.
	void OnResize(UINT width, UINT height);  // Resize the render target.
	static LRESULT CALLBACK WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);  // The windows procedure.
	HRESULT LoadBitmapFromResource(ID2D1RenderTarget* pRenderTarget, IWICImagingFactory* pIWICFactory, PCWSTR resourceName, PCWSTR resourceType, UINT destinationWidth, UINT destinationHeight, __deref_out ID2D1Bitmap** ppBitmap);
	HRESULT LoadBitmapFromFile(ID2D1RenderTarget* pRenderTarget, IWICImagingFactory* pIWICFactory, PCWSTR uri, UINT destinationWidth, UINT destinationHeight, __deref_out ID2D1Bitmap** ppBitmap);

private:
	HWND m_hwnd;
	//�̸� ������ �ؾ� ������ �� �ִ�.
	IWICImagingFactory* m_pWICFactory;
	ID2D1Factory* m_pDirect2dFactory;
	ID2D1HwndRenderTarget* m_pRenderTarget;
	ID2D1SolidColorBrush* m_pLightSlateGrayBrush;
	ID2D1SolidColorBrush* m_pCornflowerBlueBrush;

	//�׵θ�
	ID2D1SolidColorBrush* m_border_brush;

	//�ϴܻ��ڸ� �׸� �귯�� ����
	ID2D1SolidColorBrush* m_box_brush01;
	ID2D1SolidColorBrush* m_box_brush02;
	ID2D1SolidColorBrush* m_box_brush03;
	ID2D1SolidColorBrush* m_box_brush04;
	ID2D1SolidColorBrush* m_box_brush05;
	ID2D1SolidColorBrush* m_box_brush06;
	ID2D1SolidColorBrush* m_box_brush07;
	ID2D1SolidColorBrush* m_box_brush08;
	ID2D1SolidColorBrush* m_box_brush09;
	ID2D1SolidColorBrush* m_box_brush10;

	ID2D1SolidColorBrush* m_white;

	//����
	ID2D1SolidColorBrush* m_pTransparentBox;

	//�ؽ�Ʈ
	ID2D1SolidColorBrush* m_pTextBrush_white;
	ID2D1SolidColorBrush* m_pTextBrush_black;
	IDWriteFactory* m_pDWriteFactory;
	IDWriteTextFormat* m_pTextFormat;
	IDWriteTextFormat* m_pTextFormat_bigsize;

	//���
	ID2D1Bitmap* m_pBitmap;
	ID2D1Bitmap* m_pBitmap_desk;
	ID2D1Bitmap* m_ptables1;
	ID2D1Bitmap* m_ptables2;

	//ĳ����
	ID2D1Bitmap* m_pMyCharacter;
	ID2D1Bitmap* m_pOtherCharacter1;
	ID2D1Bitmap* m_pOtherCharacter2;
	ID2D1Bitmap* m_pOtherCharacter3;
	ID2D1Bitmap* m_pOtherCharacter4;
	ID2D1Bitmap* m_pOtherCharacter5;

	//��ǳ��
	ID2D1Bitmap* m_pspeech_bubble;

	//���� ����
	ID2D1Bitmap* m_pizza_dow;
	ID2D1Bitmap* m_pizza_cheese;
	ID2D1Bitmap* m_pizza_mushroom;
	ID2D1Bitmap* m_pizza_onion;
	ID2D1Bitmap* m_pizza_olive;
	ID2D1Bitmap* m_pizza_pepperoni;
	ID2D1Bitmap* m_pizza_pmang;

	// Geometry
	ID2D1PathGeometry* top_PathGeometry;
	ID2D1PathGeometry* bottom_PathGeometry;
	ID2D1PathGeometry* guest_PathGeometry;
	ID2D1PathGeometry* guest_PathGeometry_back;
	ID2D1PathGeometry* child_PathGeometry;

	//��Ʈ�ʺ귯��
	ID2D1BitmapBrush* m_pOtherCharacter1_brush;
	ID2D1BitmapBrush* m_pOtherCharacter2_brush;
	ID2D1BitmapBrush* m_pOtherCharacter3_brush;
	ID2D1BitmapBrush* m_pOtherCharacter4_brush;
	ID2D1BitmapBrush* m_pOtherCharacter5_brush;

	//�ִϸ��̼� ����
	AnimationLinear<float> m_Animation;

	//�ð� ���
	LARGE_INTEGER m_nPrevTime;
	LARGE_INTEGER m_nFrequency;

	void draw_guest(HRESULT hr, D2D1_SIZE_F rtSize);
	void draw_guest_back(HRESULT hr, D2D1_SIZE_F rtSize);

	void draw_pizza(HRESULT hr, D2D1_SIZE_F rtSize);

	void draw_pizza_state(HRESULT hr, D2D1_SIZE_F rtSize);
	void draw_pizza_name(HRESULT hr, D2D1_SIZE_F rtSize);

	void order_pizza();

};