import pymysql
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
import time

start = time.time()
x_train = []
y_train = []

model = '그랜저 IG'

W = 0.0
b = 0.0 # y = Wx + b
conn = pymysql.connect(host='localhost', port=3306, user='dbAdmin', password='xoduqrb', db='usedcardb', charset='utf8')
cur = conn.cursor()


sql = 'SELECT distance, price FROM usedCar WHERE model_detail = "' + model + '"'
cur.execute(sql)
rows = cur.fetchall()

print('길이 : ',len(rows))
for row in rows:
    x_train.append([int(row[0])])
    y_train.append([int(row[1])])
    
x_train = np.array(x_train)
y_train = np.array(y_train)

line_fitter = LinearRegression()
line_fitter.fit(X = x_train, y = y_train)

W = line_fitter.coef_[0][0]
b = line_fitter.intercept_[0]
print(line_fitter.predict([[15000]]))

print('한 매물의 주행거리 :', x_train[0])
print('한 매물의 가격 :', y_train[0])
print('매물의 예상 가격 :', line_fitter.predict([x_train[0]]))
end = time.time()

print(end-start)

plt.rc('font', family='Malgun Gothic')
plt.plot(x_train, y_train, 'o')
plt.title(model + '의 주행거리-가격 그래프')
plt.xlabel('distance', color='b')
plt.ylabel('price', color='r')
plt.plot(x_train, x_train*W+ b)
plt.show()

print('기울기 =', W)
print('절편 =', b)
