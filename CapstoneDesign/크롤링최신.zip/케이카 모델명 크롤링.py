from selenium import webdriver
from bs4 import BeautifulSoup
import urllib.request
import time

import pandas as pd
#df = pd.read_csv('modelDB.csv', sep=",", encoding='cp949') # 하다가 멈춘 파일이 있는 경우
df = pd.DataFrame([], columns=['제조사', '모델', '세부모델'])

driver = webdriver.Chrome("WebDriver/chromedriver")
homepage = "https://www.kcar.com/car/search/car_search_list.do"
driver.get(homepage)
time.sleep(4)
driver.find_element_by_xpath('//*[@id="filterSearch"]/section[1]/div[3]/ul/label[2]').click()
time.sleep(4)
makerXpath = driver.find_element_by_xpath('//*[@id="makerFrame"]/ul')
makerLen = len(makerXpath.find_elements_by_tag_name('li'))
time.sleep(4)

for i in range(makerLen):
    makerXpath = driver.find_element_by_xpath('//*[@id="makerFrame"]/ul')
    makerList = makerXpath.find_elements_by_tag_name('li')
    manufacturer = makerList[i].find_element_by_tag_name('input').get_attribute('data-v_makenm')
    print('제조사 :', manufacturer)
    manu_element = makerList[i].find_element_by_tag_name('input')
    driver.execute_script("arguments[0].click();", manu_element)
    time.sleep(4)
    
    modelCont = driver.find_element_by_xpath('//*[@id="makerFramev_makecd"]/ul')
    modelLen = len(modelCont.find_elements_by_tag_name('li'))
    for j in range(modelLen):
        modelCont = driver.find_element_by_xpath('//*[@id="makerFramev_makecd"]/ul')
        modelList = modelCont.find_elements_by_tag_name('li')
        model_name = modelList[j].find_element_by_tag_name('input').get_attribute('data-v_model_grp_nm')
        print('모델명 :', model_name)
        model_element = modelList[j].find_element_by_tag_name('input')
        driver.execute_script("arguments[0].click();", model_element)
        time.sleep(4)
        
        mdCont = driver.find_element_by_xpath('//*[@id="makerFramev_model_grp_cd"]/ul')
        mdList = mdCont.find_elements_by_tag_name('li')
        for md in mdList:
            md_name =  md.find_element_by_tag_name('input').get_attribute('data-v_modelnm')
            md_name = md_name[:md_name.rfind('(')]
            df_new = pd.DataFrame([(manufacturer, model_name, md_name)], columns=['제조사', '모델', '세부모델'])
            df = df.append(df_new, ignore_index = True)
            print('세부 모델명 :',md_name)
            
        model_element = driver.find_element_by_xpath('//*[@id="v_model_grp_cd0"]')
        driver.execute_script("arguments[0].click();", model_element)
        time.sleep(4)
        
    manu_element = driver.find_element_by_xpath('//*[@id="v_makecd0"]')
    driver.execute_script("arguments[0].click();", manu_element)
    time.sleep(4)

df = df.drop_duplicates()
df.to_csv('케이카모델명.csv', index=False, encoding='cp949')
