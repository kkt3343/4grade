import pymysql
from selenium import webdriver
from bs4 import BeautifulSoup
import urllib.request
import time
import encar_crawler

conn = pymysql.connect(host='localhost', port=3306, user='dbAdmin', password='xoduqrb', db='usedcardb', charset='utf8')
cur = conn.cursor()

driver = webdriver.Chrome("WebDriver/chromedriver")
homepage = "http://www.encar.com"
driver.get(homepage)

time.sleep(2)

handles = driver.window_handles
for handle in handles:
    if handle != handles[0]:
        driver.switch_to_window(handle)
        driver.close()
driver.switch_to_window(driver.window_handles[0])

while True:
    item_url = input('url 입력 : ')
    driver.execute_script('window.open("{0}");'.format(item_url))
    driver.implicitly_wait(10)
    time.sleep(2)
    driver.switch_to.window(driver.window_handles[1])
    encar_crawler.giveData(item_url, conn, cur, driver)
    driver.switch_to.window(driver.window_handles[0])
