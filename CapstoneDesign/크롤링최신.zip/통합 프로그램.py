import threading
import KB_crawler
import KB_crawler_i
import encar_crawler
import encar_crawler_i
import kcar_crawler
import kcar_crawler_i
import bobae_crawler
import bobae_crawler_i
import regression_update
import time

hostip = 'localhost'

# i 값에 따라
i = 6

# 0~1 : 엔카
encar_start_page = 1
encar_end_page = 15

# 2~3 : KB차차차
kb_start_page = 1
kb_end_page = 20

# 4~5 : 케이카
kcar_start_page = 1
kcar_end_page = 15

# 6~7 : 보배드림
bobae_start_page = 1
bobae_end_page = 15

# 8 : regression 업데이트

while True:
    if i == 0:
        t = threading.Thread(target=encar_crawler.start_crawling, args=(hostip, 600, encar_start_page, encar_end_page))
        t.start()
        t.join()
    elif i == 1:
        t = threading.Thread(target=encar_crawler_i.start_crawling, args=(hostip, 600, encar_start_page, encar_end_page))
        t.start()
        t.join()
    elif i == 2:
        t = threading.Thread(target=KB_crawler.start_crawling, args=(hostip, 600, kb_start_page, kb_end_page))
        t.start()
        t.join()
    elif i == 3:
        t = threading.Thread(target=KB_crawler_i.start_crawling, args=(hostip, 600, kb_start_page, kb_end_page))
        t.start()
        t.join()
    elif i == 4:
        t = threading.Thread(target=kcar_crawler.start_crawling, args=(hostip, 600, kcar_start_page, kcar_end_page))
        t.start()
        t.join()
    elif i == 5:
        t = threading.Thread(target=kcar_crawler_i.start_crawling, args=(hostip, 600, kcar_start_page, kcar_end_page))
        t.start()
        t.join()
    elif i == 6:
        t = threading.Thread(target=bobae_crawler.start_crawling, args=(hostip, 600, bobae_start_page, bobae_end_page))
        t.start()
        t.join()
    elif i == 7:
        t = threading.Thread(target=bobae_crawler_i.start_crawling, args=(hostip, 600, bobae_start_page, bobae_end_page))
        t.start()
        t.join()
    elif i == 8:
        t = threading.Thread(target=regression_update.update)
        t.start()
        t.join()
        
    time.sleep(90)
    i = (i + 1) % 9
