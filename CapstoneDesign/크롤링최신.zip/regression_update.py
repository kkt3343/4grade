import pymysql
import numpy as np
from sklearn.linear_model import LinearRegression

def update():
    conn = pymysql.connect(host='localhost', port=3306, user='dbAdmin', password='xoduqrb', db='usedcardb', charset='utf8')
    cur = conn.cursor()

    sql = 'SELECT manufacturer, model, model_detail FROM usedCar GROUP BY manufacturer, model_detail HAVING count(*) >= 5'
    cur.execute(sql)
    rows = cur.fetchall()
    for row in rows:
        manufacturer = row[0]
        model = row[1]
        model_detail = row[2]
        
        sql2 = 'SELECT distance, price FROM usedCar WHERE manufacturer = "{0}" and model = "{1}" and model_detail = "{2}"'
        sql2 = sql2.format(manufacturer, model, model_detail)
        cur.execute(sql2)
        rows2 = cur.fetchall()

        x_train = []
        y_train = []

        for row2 in rows2:
            x_train.append([int(row2[0])])
            y_train.append([int(row2[1])])

        x_train = np.array(x_train)
        y_train = np.array(y_train)
        
        line_fitter = LinearRegression()
        line_fitter.fit(X = x_train, y = y_train)
        
        coef = line_fitter.coef_[0][0]
        intercept = line_fitter.intercept_[0]

        if coef < 0:
            sql3 = 'UPDATE carModel SET coef = "{0}", intercept = "{1}"'
            sql3 = sql3 + ' WHERE manufacturer = "{2}" and model = "{3}" and model_detail = "{4}"'
            sql3= sql3.format(coef, intercept, manufacturer, model, model_detail)
            cur.execute(sql3)
            conn.commit()

            sql3 = 'UPDATE carModel_Broad SET coef = "{0}", intercept = "{1}"'
            sql3 = sql3 + ' WHERE manufacturer = "{2}" and model = "{3}" and model_detail = "{4}"'
            sql3= sql3.format(coef, intercept, manufacturer, model, model_detail)
            cur.execute(sql3)
            conn.commit()
        
    conn.close()
    print('regression 업데이트 완료')
    
