import csv
from edit_distance import edit_distance

f1 = open('보배드림 수입차 최종 모델명.csv', 'r')
reader1 = csv.reader(f1)

data = []
i = 3
for f1row in reader1:
    if len(f1row[0]) > 0:
        d = edit_distance(f1row[2], f1row[5])
        if d > 10:
            print("{0} : {1} = {2}".format(f1row[2], f1row[5], str(d)))
    i += 1
f1.close()

