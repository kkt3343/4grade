from selenium import webdriver
from bs4 import BeautifulSoup
import urllib.request
import time

import pandas as pd
#df = pd.read_csv('modelDB.csv', sep=",", encoding='cp949') # 하다가 멈춘 파일이 있는 경우
df = pd.DataFrame([], columns=['제조사', '모델', '세부모델'])

driver = webdriver.Chrome("WebDriver/chromedriver")
homepage = "https://www.encar.com"
driver.get(homepage)
time.sleep(2)

manuBox = driver.find_element_by_xpath('//*[@id="manufact"]')
manuBox = manuBox.find_element_by_tag_name('a')
manuBox.click()
time.sleep(1)
makerXpath = driver.find_element_by_xpath('//*[@id="manufactListText"]/ul[1]')
makerList = makerXpath.find_elements_by_tag_name('li')
time.sleep(1)

for i in range(1, len(makerList) + 1):
    maker = driver.find_element_by_xpath('//*[@id="manufactListText"]/ul[1]/li[num]'.replace('num', str(i)))
    manufacturer = maker.find_element_by_tag_name('a').text
    print('제조사 :', manufacturer)
    maker.find_element_by_tag_name('a').click()
    time.sleep(1)
    driver.find_element_by_xpath('//*[@id="seriesList"]/ul/li[2]/button').click()
    time.sleep(1)
    modelCont = driver.find_element_by_xpath('//*[@id="seriesItemList"]')
    modelList = modelCont.find_elements_by_tag_name('li')
    for j in range(2, len(modelList) + 1):
        model = driver.find_element_by_xpath('//*[@id="seriesItemList"]/li[num]'.replace('num', str(j)))
        model_name = model.find_element_by_tag_name('a').get_attribute('data-name')
        print('모델명 :', model_name)
        model.click()
        time.sleep(1)
        driver.find_element_by_xpath('//*[@id="mdlList"]/ul/li[2]/button').click()
        time.sleep(1)
        mdCont = driver.find_element_by_xpath('//*[@id="mdlItemList"]')
        mdList = mdCont.find_elements_by_tag_name('li')
        for k in range(2, len(mdList) + 1):
            md =  driver.find_element_by_xpath('//*[@id="mdlItemList"]/li[num]'.replace('num', str(k)))
            md_name =  md.find_element_by_tag_name('a').get_attribute('data-name')
            df_new = pd.DataFrame([(manufacturer, model_name, md_name)], columns=['제조사', '모델', '세부모델'])
            df = df.append(df_new, ignore_index = True)
            print('세부 모델명 :',md_name)
        driver.find_element_by_xpath('//*[@id="series"]/a').click()
        time.sleep(1)
        driver.find_element_by_xpath('//*[@id="seriesList"]/ul/li[2]/button').click()
        time.sleep(1)
    manuBox.click()
    time.sleep(1)

df = df.drop_duplicates()
df.to_csv('엔카모델명.csv', index=False, encoding='cp949')
