from selenium import webdriver
from bs4 import BeautifulSoup
import urllib.request
import time

import pandas as pd
#df = pd.read_csv('modelDB.csv', sep=",", encoding='cp949') # 하다가 멈춘 파일이 있는 경우
df = pd.DataFrame([], columns=['제조사', '모델', '세부모델'])

driver = webdriver.Chrome("WebDriver/chromedriver")
homepage = "https://www.kbchachacha.com/public/main.kbc"
driver.get(homepage)
time.sleep(2)

searchBox = driver.find_element_by_xpath('//*[@id="content"]/main/div[2]/div[1]/div[2]/div[1]/div/div[1]')
searchBox.find_elements_by_tag_name('a')[0].click()
time.sleep(1)
makerXpath = driver.find_element_by_xpath('//*[@id="maker-code"]/div[2]/div/ul[1]')
makerList = makerXpath.find_elements_by_tag_name('li')
time.sleep(1)

for maker in makerList:
    manufacturer = maker.find_element_by_tag_name('a').get_attribute('data-name')
    print('제조사 :', manufacturer)
    maker.find_element_by_tag_name('a').click()
    time.sleep(1)
    modelCont = driver.find_element_by_xpath('//*[@id="class-code"]/div[2]/div')
    modelList = modelCont.find_elements_by_tag_name('li')
    for model in modelList:
        model_name = model.find_element_by_tag_name('a').get_attribute('data-name')
        print('모델명 :', model_name)
        model.click()
        time.sleep(1)
        mdCont = driver.find_element_by_xpath('//*[@id="car-code"]/ul')
        mdList = mdCont.find_elements_by_tag_name('li')
        for md in mdList:
            md_name =  md.find_element_by_tag_name('a').get_attribute('data-name')
            df_new = pd.DataFrame([(manufacturer, model_name, md_name)], columns=['제조사', '모델', '세부모델'])
            df = df.append(df_new, ignore_index = True)
            
            print('세부 모델명 :',md_name)
        searchBox.find_elements_by_tag_name('a')[1].click()
        time.sleep(1)
    searchBox.find_elements_by_tag_name('a')[0].click()
    time.sleep(1)

df = df.drop_duplicates()
df.to_csv('KB모델명.csv', index=False, encoding='cp949')
